<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Book;

class BookSeeder extends Seeder
{
    public function run()
    {
        $examples = [
            ['title'=>'Những người khốn khổ','author'=>'Victor Hugo','isbn'=>'9781234567890','year'=>1862,'copies'=>3,'description'=>'Tiểu thuyết cổ điển.'],
            ['title'=>'Sapiens','author'=>'Yuval Noah Harari','isbn'=>'9780099590088','year'=>2011,'copies'=>5,'description'=>'Lịch sử loài người.'],
            ['title'=>'Atomic Habits','author'=>'James Clear','isbn'=>'9780735211292','year'=>2018,'copies'=>4,'description'=>'Thói quen hiệu quả.'],
        ];

        foreach ($examples as $e) {
            Book::create($e);
        }
    }
}
