<!doctype html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Quản lý sách</title>
  @vite(['resources/css/app.css','resources/js/app.js'])
</head>
<body class="antialiased bg-gray-50">
  <div class="container mx-auto p-4">
    <header class="mb-4">
      <h1 class="text-2xl font-bold">Quản lý sách</h1>
      <nav class="mt-2">
        <a href="{{ route('books.index') }}">Danh sách</a> |
        <a href="{{ route('books.create') }}">Thêm sách</a>
      </nav>
    </header>

    @if(session('success'))
      <div class="bg-green-100 p-2 mb-4">{{ session('success') }}</div>
    @endif

    @yield('content')
  </div>
</body>
</html>
