@extends('layouts.app')

@section('content')
<div>
  <form method="GET" action="{{ route('books.index') }}" class="mb-4">
    <input type="text" name="q" value="{{ $q ?? '' }}" placeholder="Tìm tiêu đề, tác giả...">
    <button>Tìm</button>
    <a href="{{ route('books.export.csv') }}">Xuất CSV</a>
  </form>

  <table>
    <thead>
      <tr><th>Tiêu đề</th><th>Tác giả</th><th>Năm</th><th>Copies</th><th>Hành động</th></tr>
    </thead>
    <tbody>
      @foreach($books as $book)
      <tr>
        <td><a href="{{ route('books.show', $book) }}">{{ $book->title }}</a></td>
        <td>{{ $book->author }}</td>
        <td>{{ $book->year }}</td>
        <td>{{ $book->copies }}</td>
        <td>
          <a href="{{ route('books.edit', $book) }}">Sửa</a>
          <form action="{{ route('books.destroy', $book) }}" method="POST" style="display:inline">@csrf @method('DELETE')<button> Xóa </button></form>
        </td>
      </tr>
      @endforeach
    </tbody>
  </table>

  {{ $books->withQueryString()->links() }}
</div>
@endsection
