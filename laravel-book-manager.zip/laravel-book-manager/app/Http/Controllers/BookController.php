<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;

class BookController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $q = $request->query('q');
        $books = Book::when($q, function($query, $q){
            $query->where('title', 'like', "%{$q}%")
                  ->orWhere('author', 'like', "%{$q}%")
                  ->orWhere('isbn', 'like', "%{$q}%");
        })->orderBy('title')->paginate(10);

        return view('books.index', compact('books','q'));
    }

    public function create()
    {
        return view('books.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'nullable|string|max:255',
            'isbn' => 'nullable|string|max:100',
            'year' => 'nullable|integer',
            'copies' => 'required|integer|min:0',
            'description' => 'nullable|string',
        ]);

        Book::create($data);
        return redirect()->route('books.index')->with('success', 'Đã thêm sách');
    }

    public function show(Book $book)
    {
        return view('books.show', compact('book'));
    }

    public function edit(Book $book)
    {
        return view('books.edit', compact('book'));
    }

    public function update(Request $request, Book $book)
    {
        $data = $request->validate([
            'title' => 'required|string|max:255',
            'author' => 'nullable|string|max:255',
            'isbn' => 'nullable|string|max:100',
            'year' => 'nullable|integer',
            'copies' => 'required|integer|min:0',
            'description' => 'nullable|string',
        ]);

        $book->update($data);
        return redirect()->route('books.index')->with('success', 'Đã cập nhật');
    }

    public function destroy(Book $book)
    {
        $book->delete();
        return redirect()->route('books.index')->with('success', 'Đã xóa');
    }

    public function exportCsv()
    {
        $books = Book::orderBy('title')->get();
        $filename = 'books_export_'.date('Ymd_His').'.csv';

        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => "attachment; filename=\"{$filename}\"",
        ];

        $callback = function() use ($books) {
            $handle = fopen('php://output', 'w');
            fputcsv($handle, ['ID','Title','Author','ISBN','Year','Copies','Description']);
            foreach ($books as $b) {
                fputcsv($handle, [$b->id, $b->title, $b->author, $b->isbn, $b->year, $b->copies, $b->description]);
            }
            fclose($handle);
        };

        return Response::stream($callback, 200, $headers);
    }
}
