@extends('layouts.app')

@section('content')
<h2>Sửa sách</h2>
<form action="{{ route('books.update', $book) }}" method="POST">
  @csrf
  @method('PUT')
  <div>
    <label>Tiêu đề</label>
    <input type="text" name="title" value="{{ old('title', $book->title) }}">
    @error('title')<div>{{ $message }}</div>@enderror
  </div>
  <div>
    <label>Tác giả</label>
    <input type="text" name="author" value="{{ old('author', $book->author) }}">
  </div>
  <div>
    <label>ISBN</label>
    <input type="text" name="isbn" value="{{ old('isbn', $book->isbn) }}">
  </div>
  <div>
    <label>Năm</label>
    <input type="number" name="year" value="{{ old('year', $book->year) }}">
  </div>
  <div>
    <label>Copies</label>
    <input type="number" name="copies" value="{{ old('copies', $book->copies) }}">
  </div>
  <div>
    <label>Mô tả</label>
    <textarea name="description">{{ old('description', $book->description) }}</textarea>
  </div>
  <button>Cập nhật</button>
</form>
@endsection
