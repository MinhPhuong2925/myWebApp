<?php

use App\Http\Controllers\BookController;
use Illuminate\Support\Facades\Route;

Route::get('/', function(){ return redirect()->route('books.index'); });

Route::middleware(['auth'])->group(function(){
    Route::resource('books', BookController::class);
    Route::get('books-export/csv', [BookController::class, 'exportCsv'])->name('books.export.csv');
});

require __DIR__.'/auth.php';
