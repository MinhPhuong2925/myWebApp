@extends('layouts.app')

@section('content')
<h2>{{ $book->title }}</h2>
<p><strong>Tác giả:</strong> {{ $book->author }}</p>
<p><strong>ISBN:</strong> {{ $book->isbn }}</p>
<p><strong>Năm:</strong> {{ $book->year }}</p>
<p><strong>Copies:</strong> {{ $book->copies }}</p>
<p><strong>Mô tả:</strong> {{ $book->description }}</p>
<a href="{{ route('books.edit', $book) }}">Sửa</a>
<form action="{{ route('books.destroy', $book) }}" method="POST" style="display:inline">@csrf @method('DELETE')<button> Xóa </button></form>
@endsection
