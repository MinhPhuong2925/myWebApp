@extends('layouts.app')

@section('content')
<h2>Thêm sách</h2>
<form action="{{ route('books.store') }}" method="POST">
  @csrf
  <div>
    <label>Tiêu đề</label>
    <input type="text" name="title" value="{{ old('title') }}">
    @error('title')<div>{{ $message }}</div>@enderror
  </div>
  <div>
    <label>Tác giả</label>
    <input type="text" name="author" value="{{ old('author') }}">
  </div>
  <div>
    <label>ISBN</label>
    <input type="text" name="isbn" value="{{ old('isbn') }}">
  </div>
  <div>
    <label>Năm</label>
    <input type="number" name="year" value="{{ old('year') }}">
  </div>
  <div>
    <label>Copies</label>
    <input type="number" name="copies" value="{{ old('copies', 1) }}">
  </div>
  <div>
    <label>Mô tả</label>
    <textarea name="description">{{ old('description') }}</textarea>
  </div>
  <button>Thêm</button>
</form>
@endsection
