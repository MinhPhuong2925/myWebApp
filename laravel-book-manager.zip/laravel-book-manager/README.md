# Laravel Book Manager

This is a **skeleton Laravel project** for a simple library book manager.
It includes model, controllers, routes, views, migration, and a seed.

**Important:** This zip does NOT include `vendor/`. After extracting, run:

```bash
composer install
cp .env.example .env
php artisan key:generate
# If using sqlite:
touch database/database.sqlite
php artisan migrate --seed
npm install
npm run dev
php artisan serve
```

Repo structure (important files included):
- app/Models/Book.php
- app/Http/Controllers/BookController.php
- app/Http/Controllers/Api/BookApiController.php
- database/migrations/2025_01_01_000000_create_books_table.php
- database/seeders/BookSeeder.php
- routes/web.php
- routes/api.php
- resources/views/layouts/app.blade.php
- resources/views/books/*.blade.php
- .env.example

Language: Vietnamese (UI texts). Auth scaffolding expected via Laravel Breeze (not included here).
