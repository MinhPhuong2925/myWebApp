<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Book;
use Illuminate\Http\Request;

class BookApiController extends Controller
{
    public function index(Request $request)
    {
        $q = $request->query('q');
        $books = Book::when($q, fn($query) => $query->where('title','like','%'.$q.'%'))
                     ->paginate(15);
        return response()->json($books);
    }

    public function show(Book $book)
    {
        return response()->json($book);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => 'required',
            'author' => 'nullable',
            'isbn' => 'nullable',
            'year' => 'nullable|integer',
            'copies' => 'required|integer',
        ]);

        $book = Book::create($data);
        return response()->json($book, 201);
    }

    public function update(Request $request, Book $book)
    {
        $data = $request->validate([
            'title' => 'sometimes|required',
            'author' => 'nullable',
        ]);
        $book->update($data);
        return response()->json($book);
    }

    public function destroy(Book $book)
    {
        $book->delete();
        return response()->json(null, 204);
    }
}
