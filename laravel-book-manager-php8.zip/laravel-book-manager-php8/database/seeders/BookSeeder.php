<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Book;

class BookSeeder extends Seeder
{
    public function run()
    {
        $examples = [
            ['title'=>'Những người khốn khổ','author'=>'Victor Hugo','isbn'=>'9781234567890','year'=>1862,'copies'=>3,'description'=>'Tiểu thuyết cổ điển.'],
            ['title'=>'Sapiens','author'=>'Yuval Noah Harari','isbn'=>'9780099590088','year'=>2011,'copies'=>5,'description'=>'Lịch sử loài người.'],
            ['title'=>'Atomic Habits','author'=>'James Clear','isbn'=>'9780735211292','year'=>2018,'copies'=>4,'description'=>'Thói quen hiệu quả.'],
            ['title'=>'Nhật kí Anne Frank','author'=>'Anne Frank','isbn'=>'9780553296983','year'=>1947,'copies'=>2,'description'=>'Diaries.'],
            ['title'=>'Đắc nhân tâm','author'=>'Dale Carnegie','isbn'=>'9780671027032','year'=>1936,'copies'=>6,'description'=>'Kỹ năng giao tiếp.'],
            ['title'=>'Bí mật tư duy triệu phú','author'=>'T. Harv Eker','isbn'=>'9780060763282','year'=>2005,'copies'=>4,'description'=>'Tài chính cá nhân.'],
            ['title'=>'Nghĩ giàu và làm giàu','author'=>'Napoleon Hill','isbn'=>'9781585424339','year'=>1937,'copies'=>5,'description'=>'Phát triển bản thân.'],
            ['title'=>'Tuổi trẻ đáng giá bao nhiêu','author'=>'Rosie Nguyễn','isbn'=>'9786047741234','year'=>2019,'copies'=>3,'description'=>'Truyền cảm hứng.'],
            ['title'=>'C# Programming','author'=>'Author Example','isbn'=>'9781111111111','year'=>2020,'copies'=>2,'description'=>'Programming book.'],
            ['title'=>'Laravel Up & Running','author'=>'Matt Stauffer','isbn'=>'9781492041219','year'=>2016,'copies'=>3,'description'=>'Laravel guide.'],
        ];

        foreach ($examples as $e) {
            Book::create($e);
        }
    }
}
