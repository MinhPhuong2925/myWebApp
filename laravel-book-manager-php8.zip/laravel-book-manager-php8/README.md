# Laravel Book Manager (Laravel 9, PHP 8.0 compatible)

This skeleton project is tailored to run on **PHP 8.0.x** and **Laravel 9.x**.

After extracting, run the following to get everything working:

```bash
composer install
php artisan key:generate
cp .env.example .env
# if using sqlite:
touch database/database.sqlite
php artisan migrate --seed

# Install Breeze scaffolding (if not installed via composer require)
composer require laravel/breeze --dev
php artisan breeze:install blade

# Install frontend deps and build
npm install
npm run dev

php artisan serve
```

Notes:
- This zip does NOT include `vendor/` or `node_modules/`.
- It includes model, controllers, routes, views, migration, seeders, and package.json ready for Vite.
- Language: Vietnamese UI texts.
