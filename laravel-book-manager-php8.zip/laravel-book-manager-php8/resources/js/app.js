// JS entry placeholder for Vite
